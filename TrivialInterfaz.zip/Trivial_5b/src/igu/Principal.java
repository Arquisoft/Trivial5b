package igu;

import javax.swing.JFrame;

public class Principal {

	public static void main(String[] args) {

		VentanaInicio v = new VentanaInicio();
		v.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		v.setVisible(true);
	}

}
