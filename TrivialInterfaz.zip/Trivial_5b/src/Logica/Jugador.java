package Logica;

public class Jugador {

}
